package ru.mail.park.rk1;

public interface OnItemClickListener<T> {
    void onItemClick(T item);
}